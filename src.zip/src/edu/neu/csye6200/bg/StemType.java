package edu.neu.csye6200.bg;

/**
 *
 * @author sanjay badlani
 * NUID : 001237234
 * This enumerated class defines the types of Stem that can be created.
 */
public enum StemType {
    TRUNK,
    BRANCH;
}
