
package edu.neu.csye6200.bg;

/**
 *
 * @author sanjay badlani
 * NUID : 001237234
 */
public class BGGrowthConstants {
    public static String bush = "A Bush";
    public static String pineTree = "A pine tree";
    public static String normalTreeWithTwoBranchs = "A Normal Tree With Two Branches";
    public static String normalTreeWithThreeBranchs = "A Normal Tree With Three Branches";
}
